import os
from launch import LaunchDescription
from launch.actions import ExecuteProcess
from launch_ros.actions import Node
from ament_index_python.packages import get_package_share_directory


def generate_launch_description():
    pkg_share = get_package_share_directory('quad_sim2')
    world_path = os.path.join(pkg_share, 'worlds', 'quad_world.sdf')

    install_prefix = os.path.dirname(os.path.dirname(pkg_share))
    teleop_script = os.path.join(install_prefix, 'lib', 'quad_sim2', 'quad_teleop.py')
    navigator_script = os.path.join(install_prefix, 'lib', 'quad_sim2', 'go_to_position.py')
    gps_converter_script = os.path.join(install_prefix, 'lib', 'quad_sim2', 'gps_odom_converter.py')

    # Launch Gazebo Harmonic with the GPS/odometry-enabled quadcopter world
    gz_sim = ExecuteProcess(
        cmd=['gz', 'sim', world_path],
        output='screen'
    )

    # Bridge topics between ROS2 and Gazebo:
    #  - cmd_vel: ROS2 -> Gazebo (teleop / navigation commands)
    #  - enable: ROS2 -> Gazebo (kill-switch for the velocity controller)
    #  - odometry: Gazebo -> ROS2 (ground-truth pose/velocity, for comparison)
    #  - target_position: Gazebo -> ROS2 (set from the GUI "Set Target
    #    Position" panel, consumed by go_to_position.py)
    #  - navsat: Gazebo -> ROS2 (raw GPS lat/lon/alt, consumed by
    #    gps_odom_converter.py)
    bridge = Node(
        package='ros_gz_bridge',
        executable='parameter_bridge',
        arguments=[
            '/quadcopter/cmd_vel@geometry_msgs/msg/Twist@gz.msgs.Twist',
            '/quadcopter/enable@std_msgs/msg/Bool@gz.msgs.Boolean',
            '/quadcopter/odometry@nav_msgs/msg/Odometry@gz.msgs.Odometry',
            '/quadcopter/target_position@geometry_msgs/msg/Pose@gz.msgs.Pose',
            '/quadcopter/navsat@sensor_msgs/msg/NavSatFix@gz.msgs.NavSat',
        ],
        output='screen'
    )

    # Converts GPS lat/lon fixes into local x/y/z odometry, and also
    # republishes onto Gazebo Transport so it's visible in the GUI's
    # TopicEcho panel
    gps_converter = ExecuteProcess(
        cmd=['python3', gps_converter_script],
        output='screen'
    )

    # Autonomous point-to-point navigation — listens for a target on
    # /quadcopter/target_position (set via the GUI panel) and flies there
    # using GPS-derived position feedback
    navigator = ExecuteProcess(
        cmd=['python3', navigator_script],
        output='screen'
    )

    # Manual override: 3D keyboard teleop, run in its own terminal so it
    # can capture keystrokes
    teleop = ExecuteProcess(
        cmd=['gnome-terminal', '--', 'bash', '-c',
             'python3 ' + teleop_script + '; echo; echo "[teleop exited, press Enter to close]"; read'],
        output='screen'
    )

    return LaunchDescription([
        gz_sim,
        bridge,
        gps_converter,
        navigator,
        teleop,
    ])
