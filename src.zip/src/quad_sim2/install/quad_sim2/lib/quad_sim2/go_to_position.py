#!/usr/bin/env python3
"""
Autonomous point-to-point navigation for the quadcopter (no obstacles).

Uses a simple proportional (P) controller: the further from the target,
the faster it commands the drone to move. As the error shrinks, so does
the commanded velocity, producing a smooth, non-overshooting approach.

Subscribes:  /quadcopter/odometry   (nav_msgs/Odometry)
Publishes:   /quadcopter/cmd_vel    (geometry_msgs/Twist)

NOTE: assumes cmd_vel is interpreted in the WORLD frame by
MulticopterVelocityControl, matching how we've sent raw x/y/z commands
throughout this project. If the drone drifts diagonally instead of
heading straight at the target, that assumption needs revisiting.

Usage:
  ros2 run quad_sim1 go_to_position.py --ros-args -p target_x:=3.0 -p target_y:=2.0 -p target_z:=1.5
"""

import math

import rclpy
from rclpy.node import Node
from geometry_msgs.msg import Twist, Pose
from nav_msgs.msg import Odometry

MAX_LINEAR_SPEED = 1.5   # m/s — hard cap regardless of how far away the target is
KP = 0.6                  # proportional gain — higher = more aggressive approach
POSITION_TOLERANCE = 0.1  # meters — considered "arrived" within this radius


class GoToPosition(Node):
    def __init__(self):
        super().__init__('go_to_position')

        # No fixed target at startup — waits for one on /quadcopter/target_position
        self.target_x = None
        self.target_y = None
        self.target_z = None

        self.current_x = 0.0
        self.current_y = 0.0
        self.current_z = 0.0
        self.have_odom = False
        self.have_target = False
        self.arrived = False

        self.cmd_pub = self.create_publisher(Twist, '/quadcopter/cmd_vel', 10)
        self.odom_sub = self.create_subscription(
            Odometry, '/quadcopter/gps_odometry', self.odom_callback, 10)
        self.target_sub = self.create_subscription(
            Pose, '/quadcopter/target_position', self.target_callback, 10)

        # Control loop at 20Hz
        self.timer = self.create_timer(1.0 / 20.0, self.control_loop)

        self.get_logger().info(
            'Waiting for a target on /quadcopter/target_position '
            '(publish from the Gazebo GUI "Set Target Position" panel)'
        )

    def odom_callback(self, msg: Odometry):
        self.current_x = msg.pose.pose.position.x
        self.current_y = msg.pose.pose.position.y
        self.current_z = msg.pose.pose.position.z
        self.have_odom = True

    def target_callback(self, msg: Pose):
        # A new target arrived (e.g. from the GUI panel) — adopt it
        # immediately and re-arm navigation, even if we'd already arrived
        # at a previous target.
        self.target_x = msg.position.x
        self.target_y = msg.position.y
        self.target_z = msg.position.z
        self.have_target = True
        self.arrived = False
        self.get_logger().info(
            f'New target received: ({self.target_x}, {self.target_y}, {self.target_z})'
        )

    def control_loop(self):
        if not self.have_odom or not self.have_target or self.arrived:
            return

        error_x = self.target_x - self.current_x
        error_y = self.target_y - self.current_y
        error_z = self.target_z - self.current_z

        distance = math.sqrt(error_x**2 + error_y**2 + error_z**2)

        if distance < POSITION_TOLERANCE:
            self.stop()
            self.arrived = True
            self.get_logger().info(
                f'Arrived at target (within {POSITION_TOLERANCE}m). Holding position.'
            )
            return

        # Proportional control: velocity scales with distance from target
        vx = KP * error_x
        vy = KP * error_y
        vz = KP * error_z

        # Clamp to max speed while preserving direction
        speed = math.sqrt(vx**2 + vy**2 + vz**2)
        if speed > MAX_LINEAR_SPEED:
            scale = MAX_LINEAR_SPEED / speed
            vx *= scale
            vy *= scale
            vz *= scale

        msg = Twist()
        msg.linear.x = vx
        msg.linear.y = vy
        msg.linear.z = vz
        self.cmd_pub.publish(msg)

    def stop(self):
        self.cmd_pub.publish(Twist())  # all-zero Twist


def main():
    rclpy.init()
    node = GoToPosition()
    try:
        rclpy.spin(node)
    except KeyboardInterrupt:
        pass
    finally:
        node.stop()
        node.destroy_node()
        rclpy.shutdown()


if __name__ == '__main__':
    main()
