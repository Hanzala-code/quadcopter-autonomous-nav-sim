# quad_final — dynamic UAV navigation for `maze_world`

This version keeps the original `quad_final` Gazebo/ROS 2 stack as the main package and adds the most useful behavior from `autonomous-uav-navigation-system` without replacing the Gazebo multicopter interface.

## What changed

- **Full maze-aware global planning:** the planner now models the wall geometry from `world_maze1.sdf` instead of only three sample obstacles.
- **Dynamic A* replanning:** the planner consumes predicted obstacle boxes and replans at 2 Hz.
- **Camera obstacle perception:** RGB-D point clouds are voxelized, clustered, temporally confirmed, and transformed into the world frame.
- **Moving-obstacle tracking:** obstacle centroids are tracked across frames and short-horizon motion is predicted before planning.
- **LiDAR fusion:** a 360° GPU LiDAR was added to the simulated vehicle; the local controller fuses it with the camera for a conservative near-field safety decision.
- **Reactive local avoidance:** path following is continuously modified using front/side clearance, speed throttling, lateral repulsion, and emergency reverse/turn behavior.
- **Body-frame command handling:** the Gazebo multicopter velocity controller receives body-frame velocities while the planner/controller reasons in world coordinates.
- **Actual odometry TF:** `world -> quadcopter/base_link` now uses the simulator's timestamped pose/orientation.
- **RViz goal bridge:** RViz `2D Goal Pose` is bridged into the package target topic, with a configurable default flight altitude of 2.0 m.
- **Dynamic-obstacle test driver:** an optional test node moves `dynamic_test_box` through the maze using Gazebo's user-command pose service.

## Architecture

```text
RGB-D camera --------------------> obstacle_detector ----> detected_obstacles
                                           |
                                           v
                                    obstacle_tracker
                                           |
                                           v
                                    tracked_obstacles
                                           |
                                           v
Goal pose --> path_planner --> planned_path --> smart navigator --> /quadcopter/cmd_vel
                    ^                              ^
                    |                              |
             maze wall geometry              camera + LiDAR
                    |
                    +--------------------- local reactive safety
```

The planner and the local controller are intentionally separate. A global replan can take a little time; the local controller still reduces speed or stops/turns immediately when a close obstacle is detected.

## Run

Build and source the workspace:

```bash
colcon build --packages-select quad_final
source install/setup.bash
```

Launch the complete system:

```bash
ros2 launch quad_final quad_final.launch.py
```

Launch with the moving-obstacle test target:

```bash
ros2 launch quad_final quad_final.launch.py use_dynamic_demo:=true
```

Launch keyboard teleoperation for manual tests only:

```bash
ros2 launch quad_final quad_final.launch.py use_teleop:=true
```

Do not run teleop and autonomous navigation together unless you deliberately want competing command sources.

## Recommended dynamic-obstacle test

1. Start with `use_dynamic_demo:=true`.
2. Give the quadcopter a goal in the lower maze corridor, around `(5, -5)` at about `z=2.0`.
3. Watch the RViz layers for `/quadcopter/detected_obstacles`, `/quadcopter/tracked_obstacles`, `/quadcopter/planned_path`, and `/quadcopter/avoidance_debug`.
4. Move the test box across the intended corridor. The camera should detect it, the tracker should estimate its motion, the planner should route around its predicted footprint, and the local controller should still intervene if the vehicle gets too close.

## Key topics

| Topic | Purpose |
|---|---|
| `/quadcopter/camera/points` | RGB-D point cloud |
| `/quadcopter/scan` | Simulated 360° LiDAR |
| `/quadcopter/detected_obstacles` | Confirmed camera obstacle boxes |
| `/quadcopter/tracked_obstacles` | Predicted moving obstacle boxes |
| `/quadcopter/planned_path` | Dynamic global path |
| `/quadcopter/avoidance_debug` | Local avoidance debug markers |
| `/quadcopter/avoidance_status` | Human-readable controller state |
| `/quadcopter/cmd_vel` | Final body-frame velocity command |
| `/quadcopter/target_position` | Navigation goal |

## Important tuning points

The most important values for experimentation are in `scripts/go_to_position.py`, `scripts/obstacle_detector.py`, `scripts/obstacle_tracker.py`, and `scripts/path_planner.py`.

- Raise the camera/LiDAR safety margins if the vehicle gets too close to obstacles.
- Lower maximum horizontal speed if the simulated vehicle overshoots corners.
- Increase tracker prediction horizon for faster moving obstacles, at the cost of more conservative detours.
- Increase planner inflation to account for vehicle body size and localization error.

## Notes about the reference package

The reference package contributed the useful design ideas: depth/LiDAR fusion, near-field reactive avoidance, speed reduction based on frontal clearance, wall sliding/side repulsion, look-ahead path following, and dynamic occupancy-aware replanning. Its PX4 Offboard-specific control path was not copied into `quad_final` because this world uses Gazebo's `MulticopterVelocityControl`, which accepts body-frame velocity commands.

## Validation status

The package files were syntax-checked and the maze planner's grid connectivity was tested here. A complete ROS 2 + Gazebo launch test could not be executed in this environment because ROS 2/Gazebo and packages such as `rclpy`, `sensor_msgs`, `tf2_ros`, and `ros_gz_bridge` are not installed here. Runtime tuning on the target ROS 2/Gazebo machine is therefore still required.
