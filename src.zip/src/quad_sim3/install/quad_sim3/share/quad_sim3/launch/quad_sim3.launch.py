import os
from launch import LaunchDescription
from launch.actions import ExecuteProcess
from launch_ros.actions import Node
from ament_index_python.packages import get_package_share_directory


def generate_launch_description():
    pkg_share = get_package_share_directory('quad_sim3')
    world_path = os.path.join(pkg_share, 'worlds', 'quad_world.sdf')

    install_prefix = os.path.dirname(os.path.dirname(pkg_share))
    teleop_script = os.path.join(install_prefix, 'lib', 'quad_sim3', 'quad_teleop.py')
    navigator_script = os.path.join(install_prefix, 'lib', 'quad_sim3', 'go_to_position.py')
    gps_converter_script = os.path.join(install_prefix, 'lib', 'quad_sim3', 'gps_odom_converter.py')
    odom_tf_script = os.path.join(install_prefix, 'lib', 'quad_sim3', 'odom_tf_broadcaster.py')

    # Launch Gazebo Harmonic with the GPS/odometry-enabled quadcopter world
    gz_sim = ExecuteProcess(
        cmd=['gz', 'sim', world_path],
        output='screen'
    )

    # Bridge topics between ROS2 and Gazebo:
    #  - cmd_vel: ROS2 -> Gazebo (teleop / navigation commands)
    #  - enable: ROS2 -> Gazebo (kill-switch for the velocity controller)
    #  - odometry: Gazebo -> ROS2 (ground-truth pose/velocity, for comparison)
    #  - target_position: Gazebo -> ROS2 (set from the GUI "Set Target
    #    Position" panel, consumed by go_to_position.py)
    #  - navsat: Gazebo -> ROS2 (raw GPS lat/lon/alt, consumed by
    #    gps_odom_converter.py)
    #  - camera/points, /image, /camera_info: Gazebo -> ROS2 (front-facing
    #    depth camera: point cloud, color image, and calibration info)
    bridge = Node(
        package='ros_gz_bridge',
        executable='parameter_bridge',
        arguments=[
            '/quadcopter/cmd_vel@geometry_msgs/msg/Twist@gz.msgs.Twist',
            '/quadcopter/enable@std_msgs/msg/Bool@gz.msgs.Boolean',
            '/quadcopter/odometry@nav_msgs/msg/Odometry@gz.msgs.Odometry',
            '/quadcopter/target_position@geometry_msgs/msg/Pose@gz.msgs.Pose',
            '/quadcopter/navsat@sensor_msgs/msg/NavSatFix@gz.msgs.NavSat',
            '/quadcopter/camera/points@sensor_msgs/msg/PointCloud2@gz.msgs.PointCloudPacked',
            '/quadcopter/camera/image@sensor_msgs/msg/Image@gz.msgs.Image',
            '/quadcopter/camera/camera_info@sensor_msgs/msg/CameraInfo@gz.msgs.CameraInfo',
            '/clock@rosgraph_msgs/msg/Clock[gz.msgs.Clock',
        ],
        output='screen',
        parameters=[{'use_sim_time': True}]
    )

    # Converts GPS lat/lon fixes into local x/y/z odometry, and also
    # republishes onto Gazebo Transport so it's visible in the GUI's
    # TopicEcho panel
    gps_converter = ExecuteProcess(
        cmd=['python3', gps_converter_script, '--ros-args', '-p', 'use_sim_time:=true'],
        output='screen'
    )

    # Autonomous point-to-point navigation — listens for a target on
    # /quadcopter/target_position (set via the GUI panel) and flies there
    # using GPS-derived position feedback
    navigator = ExecuteProcess(
        cmd=['python3', navigator_script, '--ros-args', '-p', 'use_sim_time:=true'],
        output='screen'
    )

    # Manual override: 3D keyboard teleop, run in its own terminal so it
    # can capture keystrokes
    teleop = ExecuteProcess(
        cmd=['gnome-terminal', '--', 'bash', '-c',
             'python3 ' + teleop_script + '; echo; echo "[teleop exited, press Enter to close]"; read'],
        output='screen'
    )

    # RViz2 for point cloud visualization (Gazebo's own GUI can't render
    # point clouds — only the camera's 2D image feed, via the ImageDisplay
    # panel already in the world file)
    rviz = Node(
        package='rviz2',
        executable='rviz2',
        output='screen',
        parameters=[{'use_sim_time': True}]
    )

    # Static transform: the camera is rigidly bolted to base_link at a
    # fixed 0.2m forward offset (matching the sensor's <pose> in the SDF).
    # Without this, RViz has no way to know how the point cloud's frame
    # relates to base_link, and refuses to render it.
    camera_tf = Node(
        package='tf2_ros',
        executable='static_transform_publisher',
        arguments=[
            '--x', '0.2', '--y', '0', '--z', '0',
            '--roll', '0', '--pitch', '0', '--yaw', '0',
            '--frame-id', 'quadcopter/base_link',
            '--child-frame-id', 'quadcopter/base_link/front_rgbd_camera',
        ],
        output='screen'
    )

    # Dynamic transform: world -> quadcopter/base_link, updates continuously
    # as the drone moves (unlike the static camera mount above). This is
    # what makes "world" usable as a Fixed Frame in RViz.
    # use_sim_time is critical here: this transform must be timestamped
    # using the SAME clock domain as the point cloud (Gazebo sim time),
    # or tf2 can never match them up for interpolation.
    odom_tf = ExecuteProcess(
        cmd=['python3', odom_tf_script, '--ros-args', '-p', 'use_sim_time:=true'],
        output='screen'
    )

    return LaunchDescription([
        gz_sim,
        bridge,
        gps_converter,
        navigator,
        teleop,
        rviz,
        camera_tf,
        odom_tf,
    ])