#!/usr/bin/env python3
"""
Dynamic TF broadcaster for the quadcopter.

Unlike the static camera transform (fixed offset, never changes), this
transform changes every time the drone moves — so it must be
re-broadcast continuously, once per odometry update.

This is what lets "world" become a valid Fixed Frame in RViz: without
it, RViz has no idea where quadcopter/base_link is relative to any
world-anchored frame, only relative to itself.

NOTE: uses /quadcopter/gps_odometry, matching what go_to_position.py
uses as its position source. Since our GPS conversion doesn't derive
orientation (see gps_odom_converter.py), this broadcasts an identity
rotation — fine while the drone isn't yawing significantly, but if you
add real orientation sensing (IMU) later, that should feed this instead.

Subscribes: /quadcopter/gps_odometry (nav_msgs/Odometry)
Broadcasts: TF transform, world -> quadcopter/base_link
"""

import rclpy
from rclpy.node import Node
from nav_msgs.msg import Odometry
from tf2_ros import TransformBroadcaster
from geometry_msgs.msg import TransformStamped


class OdomTfBroadcaster(Node):
    def __init__(self):
        super().__init__('odom_tf_broadcaster')

        self.broadcaster = TransformBroadcaster(self)
        self.sub = self.create_subscription(
            Odometry, '/quadcopter/gps_odometry', self.odom_callback, 10)

        self.get_logger().info('Broadcasting world -> quadcopter/base_link TF')

    def odom_callback(self, msg: Odometry):
        t = TransformStamped()
        t.header.stamp = self.get_clock().now().to_msg()
        t.header.frame_id = 'world'
        t.child_frame_id = 'quadcopter/base_link'

        t.transform.translation.x = msg.pose.pose.position.x
        t.transform.translation.y = msg.pose.pose.position.y
        t.transform.translation.z = msg.pose.pose.position.z

        t.transform.rotation = msg.pose.pose.orientation

        self.broadcaster.sendTransform(t)


def main():
    rclpy.init()
    node = OdomTfBroadcaster()
    try:
        rclpy.spin(node)
    except KeyboardInterrupt:
        pass
    finally:
        node.destroy_node()
        rclpy.shutdown()


if __name__ == '__main__':
    main()
