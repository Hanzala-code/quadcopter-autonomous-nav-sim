#!/usr/bin/env python3
"""
D* Lite path planner for the quadcopter, with static + dynamic obstacles.

Same external interface as before: takes the drone's current position
(GPS-derived odometry) and a target (GUI panel), publishes a waypoint
nav_msgs/Path for go_to_position.py to follow, and replans when a newly
detected obstacle actually blocks the current path.

Subscribes:  /quadcopter/gps_odometry       (nav_msgs/Odometry)
             /quadcopter/target_position    (geometry_msgs/Pose)
             /quadcopter/detected_obstacles  (visualization_msgs/MarkerArray)
Publishes:   /quadcopter/planned_path       (nav_msgs/Path)

Fixes vs previous version
──────────────────────────
FIX 1 — Cooldown applies to ATTEMPTS, not just successful replans.
  Previously last_replan_time was only reset inside publish_from_dstar(),
  so when D* Lite returned "No path found" the timestamp was never
  updated and the next camera frame immediately triggered another
  attempt. This produced the rapid-fire "No path found" spam in the
  logs. Now last_replan_time is updated at the START of any replan
  attempt regardless of outcome.

FIX 2 — path_blocked check happens BEFORE updating DYNAMIC_OBSTACLES.
  Previously obstacle_callback() cleared and rebuilt DYNAMIC_OBSTACLES
  first, then called path_blocked() — which calls is_occupied() which
  reads DYNAMIC_OBSTACLES. So path_blocked always saw the NEW obstacles
  and reported "blocked" on every frame the obstacle was visible,
  regardless of whether the path was actually affected. Now the check
  uses the OLD obstacle set (pre-update), which correctly answers "does
  this NEW detection change whether our CURRENT path is blocked?"

FIX 3 — snapshot_occupancy() is only called when a replan actually
  happens, not on every obstacle message. Previously it iterated all
  1600 grid cells at 9 Hz even when the cooldown made the result
  irrelevant.

FIX 4 — DYNAMIC_OBSTACLES is now an instance variable (self._dynamic),
  not a module-level global. This eliminates the race between
  obstacle_callback mutating the list while is_occupied reads it during
  a concurrent replan triggered from the same callback chain.
"""

import math
import heapq
import itertools

import rclpy
from rclpy.node import Node
from geometry_msgs.msg import Pose, PoseStamped
from nav_msgs.msg import Odometry, Path
from visualization_msgs.msg import Marker, MarkerArray

# ---- Grid / arena config — must match quad_world.sdf wall placement ----
ARENA_MIN = -10.0
ARENA_MAX = 10.0
CELL_SIZE = 0.5   # meters per grid cell
GRID_DIM = int((ARENA_MAX - ARENA_MIN) / CELL_SIZE)  # 40 x 40 cells

# Static obstacle rectangles as (xmin, xmax, ymin, ymax) in world metres.
# Empty for now — the arena wall is handled via the grid boundary + INFLATION.
# Static obstacle bounding boxes (xmin, xmax, ymin, ymax) in world metres.
# These MUST match the obstacle poses and sizes in quad_world.sdf exactly.
# obstacle_1:            pose=(3,-4),  size=(1,1,2)
# obstacle_l_horizontal: pose=(3, 1),  size=(2,0.2,2)
# obstacle_l_vertical:   pose=(2, 2),  size=(0.2,2,2)
STATIC_OBSTACLES = [
    (2.50, 3.50, -4.50, -3.50),   # obstacle_1
    (2.00, 4.00,  0.90,  1.10),   # obstacle_l_horizontal
    (1.90, 2.10,  1.00,  3.00),   # obstacle_l_vertical
]

# # Static obstacle bounding boxes (xmin, xmax, ymin, ymax) in world metres.
# These MUST match the new world obstacles exactly.
# STATIC_OBSTACLES = [
#     (-9.00, -3.00, -9.00, -3.00),   # terrain_mound_1 (box: 6x6, centered at -6, -6)
#     ( 3.50,  8.50,  3.50,  8.50),   # terrain_mound_2 (box: 5x5, centered at 6, 6)
#     ( 3.40,  4.60,  2.40,  3.60),   # pillar_1 (cylinder radius 0.6, centered at 4, 3)
#     (-3.50, -2.50,  3.50,  4.50),   # pillar_2 (cylinder radius 0.5, centered at -3, 4)
#     (-4.70, -3.30, -3.70, -2.30),   # pillar_3 (cylinder radius 0.7, centered at -4, -3)
#     ( 0.49,  3.51, -4.55, -1.45),   # barrier_central (box: 3x0.8 rotated ~45° at 2, -3)
# ]

# How much to inflate every obstacle (and the arena wall boundary) in
# metres, so the drone's body stays clear of hard edges.
INFLATION = 0.4

# Minimum time (seconds) between obstacle-triggered replan ATTEMPTS.
# Raised from the old value — the previous 2 s only applied to successful
# replans (see FIX 1 above), so in practice the real gap was ~0 s.
REPLAN_COOLDOWN_SEC = 2.0

NEIGHBORS = [(-1, -1), (-1, 0), (-1, 1),
             (0,  -1),          (0,  1),
             (1,  -1), (1,  0), (1,  1)]


def world_to_grid(x, y):
    gx = int((x - ARENA_MIN) / CELL_SIZE)
    gy = int((y - ARENA_MIN) / CELL_SIZE)
    return gx, gy


def grid_to_world(gx, gy):
    x = ARENA_MIN + (gx + 0.5) * CELL_SIZE
    y = ARENA_MIN + (gy + 0.5) * CELL_SIZE
    return x, y


def in_bounds(gx, gy):
    return 0 <= gx < GRID_DIM and 0 <= gy < GRID_DIM


def is_occupied(gx, gy, dynamic_obstacles):
    """Return True if this grid cell is inside any obstacle or too close
    to an arena wall.  dynamic_obstacles is passed explicitly so callers
    can control WHICH snapshot of obstacles is used (FIX 2)."""
    x, y = grid_to_world(gx, gy)
    # Arena wall inflation
    if (x - ARENA_MIN) < INFLATION or (ARENA_MAX - x) < INFLATION:
        return True
    if (y - ARENA_MIN) < INFLATION or (ARENA_MAX - y) < INFLATION:
        return True
    # Static + dynamic obstacles
    for (xmin, xmax, ymin, ymax) in STATIC_OBSTACLES + dynamic_obstacles:
        if (xmin - INFLATION) <= x <= (xmax + INFLATION) and \
           (ymin - INFLATION) <= y <= (ymax + INFLATION):
            return True
    return False


def simplify_path(waypoints):
    """Drop collinear intermediate waypoints."""
    if len(waypoints) <= 2:
        return waypoints
    simplified = [waypoints[0]]
    for i in range(1, len(waypoints) - 1):
        x0, y0 = simplified[-1]
        x1, y1 = waypoints[i]
        x2, y2 = waypoints[i + 1]
        cross = (x1 - x0) * (y2 - y0) - (y1 - y0) * (x2 - x0)
        if abs(cross) > 1e-6:
            simplified.append(waypoints[i])
    simplified.append(waypoints[-1])
    return simplified


# ---------------------------------------------------------------------------
# D* Lite search
# ---------------------------------------------------------------------------

class DStarLite:
    """Incremental replanning search over the module-level grid.
    One instance persists for the lifetime of a single (start→goal) pair.
    A new target requires re-initialising; obstacle changes during flight
    to the SAME target reuse the existing state via notify_changed().

    dynamic_obstacles is stored as a reference to the planner's list so
    all cost/occupancy queries always see the version passed at plan time.
    """

    def __init__(self, dynamic_obstacles):
        # dynamic_obstacles is the live list owned by PathPlanner —
        # passed in so DStarLite.cost() always uses the right snapshot.
        self._dynamic = dynamic_obstacles
        self.g = {}
        self.rhs = {}
        self.U = []
        self.entry_finder = {}
        self.counter = itertools.count()
        self.km = 0.0
        self.start = None
        self.goal = None

    def _is_occupied(self, gx, gy):
        return is_occupied(gx, gy, self._dynamic)

    @staticmethod
    def h(a, b):
        return math.hypot(a[0] - b[0], a[1] - b[1])

    def neighbors_of(self, s):
        result = []
        for dx, dy in NEIGHBORS:
            n = (s[0] + dx, s[1] + dy)
            if in_bounds(*n):
                result.append(n)
        return result

    def cost(self, u, v):
        if self._is_occupied(*u) or self._is_occupied(*v):
            return math.inf
        return math.hypot(v[0] - u[0], v[1] - u[1])

    def calc_key(self, s):
        g_rhs = min(self.g.get(s, math.inf), self.rhs.get(s, math.inf))
        return (g_rhs + self.h(s, self.start) + self.km, g_rhs)

    def _insert(self, s):
        entry = [self.calc_key(s), next(self.counter), s]
        self.entry_finder[s] = entry
        heapq.heappush(self.U, entry)

    def _remove(self, s):
        entry = self.entry_finder.pop(s, None)
        if entry is not None:
            entry[2] = None  # lazy delete

    def top_key(self):
        while self.U:
            key, _, s = self.U[0]
            if s is None:
                heapq.heappop(self.U)
                continue
            return key
        return (math.inf, math.inf)

    def _pop(self):
        while self.U:
            key, _, s = heapq.heappop(self.U)
            if s is None:
                continue
            self.entry_finder.pop(s, None)
            return key, s
        return None, None

    def update_vertex(self, u):
        if u != self.goal:
            best = math.inf
            for s in self.neighbors_of(u):
                c = self.cost(u, s)
                if c < math.inf:
                    best = min(best, self.g.get(s, math.inf) + c)
            self.rhs[u] = best
        if u in self.entry_finder:
            self._remove(u)
        if self.g.get(u, math.inf) != self.rhs.get(u, math.inf):
            self._insert(u)

    def compute_shortest_path(self):
        while True:
            start_key = self.calc_key(self.start)
            top_k = self.top_key()
            if not (top_k < start_key) and \
               self.rhs.get(self.start, math.inf) == self.g.get(self.start, math.inf):
                break
            k_old, u = self._pop()
            if u is None:
                break
            k_new = self.calc_key(u)
            if k_old < k_new:
                self._insert(u)
            elif self.g.get(u, math.inf) > self.rhs.get(u, math.inf):
                self.g[u] = self.rhs[u]
                for s in self.neighbors_of(u):
                    self.update_vertex(s)
            else:
                self.g[u] = math.inf
                self.update_vertex(u)
                for s in self.neighbors_of(u):
                    self.update_vertex(s)

    def initialize(self, start, goal):
        self.g = {}
        self.rhs = {}
        self.U = []
        self.entry_finder = {}
        self.km = 0.0
        self.start = start
        self.goal = goal
        self.rhs[goal] = 0.0
        self._insert(goal)

    def update_start(self, new_start):
        self.km += self.h(self.start, new_start)
        self.start = new_start

    def notify_changed(self, changed_cells):
        affected = set()
        for c in changed_cells:
            affected.add(c)
            affected.update(self.neighbors_of(c))
        for u in affected:
            self.update_vertex(u)

    def extract_path(self, max_len=2000):
        if self.g.get(self.start, math.inf) == math.inf:
            return None
        path = [self.start]
        current = self.start
        for _ in range(max_len):
            if current == self.goal:
                return path
            best_next, best_cost = None, math.inf
            for s in self.neighbors_of(current):
                c = self.cost(current, s)
                if c == math.inf:
                    continue
                total = c + self.g.get(s, math.inf)
                if total < best_cost:
                    best_cost, best_next = total, s
            if best_next is None:
                return None
            current = best_next
            path.append(current)
        return None


# ---------------------------------------------------------------------------
# ROS 2 node
# ---------------------------------------------------------------------------

class PathPlanner(Node):
    def __init__(self):
        super().__init__('path_planner')

        self.current_x = 0.0
        self.current_y = 0.0
        self.have_odom = False

        self.current_target = None       # (x, y, z) of the last accepted target
        self.current_path_world = []     # [(x, y), ...] of the last published path

        # FIX 4: instance variable instead of module-level global so
        # is_occupied() / DStarLite.cost() always receive the right
        # snapshot and there is no cross-callback mutation race.
        self._dynamic_obstacles = []

        # FIX 1: cooldown is tracked per attempt, not per successful publish.
        self.last_replan_attempt = self.get_clock().now()

        self.dstar = DStarLite(self._dynamic_obstacles)
        self.occupancy_cache = set()

        self.path_pub = self.create_publisher(Path, '/quadcopter/planned_path', 10)
        self.odom_sub = self.create_subscription(
            Odometry, '/quadcopter/gps_odometry', self.odom_callback, 10)
        self.target_sub = self.create_subscription(
            Pose, '/quadcopter/target_position', self.target_callback, 10)
        self.obstacle_sub = self.create_subscription(
            MarkerArray, '/quadcopter/detected_obstacles', self.obstacle_callback, 10)

        self.get_logger().info(
            f'Path planner ready (D* Lite) — grid {GRID_DIM}x{GRID_DIM} cells, '
            f'{CELL_SIZE}m/cell, {len(STATIC_OBSTACLES)} static obstacle(s). '
            'Waiting for a target on /quadcopter/target_position.'
        )

    # ------------------------------------------------------------------
    # Subscribers
    # ------------------------------------------------------------------

    def odom_callback(self, msg: Odometry):
        self.current_x = msg.pose.pose.position.x
        self.current_y = msg.pose.pose.position.y
        self.have_odom = True

    def target_callback(self, msg: Pose):
        if not self.have_odom:
            self.get_logger().warn(
                'No odometry yet — ignoring target until position is known.')
            return

        new_target = (
            round(msg.position.x, 2),
            round(msg.position.y, 2),
            round(msg.position.z, 2),
        )
        if new_target == self.current_target:
            return  # GUI panel repeats the same target periodically — ignore

        self.start_new_plan(msg.position.x, msg.position.y, msg.position.z)

    def obstacle_callback(self, msg: MarkerArray):
        # FIX 2: check whether the CURRENT path is blocked using the
        # OLD obstacle set BEFORE we update it.  This correctly answers
        # "does this new detection change our situation?" rather than
        # "is our path blocked by the new obstacles?" (which is always
        # true while the obstacle is visible, cooldown or not).
        old_path = list(self.current_path_world)

        # Rebuild the live obstacle list from the incoming markers.
        self._dynamic_obstacles.clear()
        for m in msg.markers:
            if m.action == Marker.DELETEALL:
                continue
            xmin = m.pose.position.x - m.scale.x / 2.0
            xmax = m.pose.position.x + m.scale.x / 2.0
            ymin = m.pose.position.y - m.scale.y / 2.0
            ymax = m.pose.position.y + m.scale.y / 2.0
            self._dynamic_obstacles.append((xmin, xmax, ymin, ymax))

        if not self.current_target or not old_path:
            return

        # FIX 1: enforce cooldown on ATTEMPTS, not just successful publishes.
        elapsed = (self.get_clock().now() - self.last_replan_attempt).nanoseconds / 1e9
        if elapsed < REPLAN_COOLDOWN_SEC:
            return

        # Replan if the path is blocked by current obstacles.
        # We check old_path (the path we're currently following) against
        # the NEW obstacle set. The cooldown above handles throttling so
        # we don't replan on every camera frame.
        now_blocked = self._path_blocked(old_path, self._dynamic_obstacles)

        if now_blocked:
            self.get_logger().warn(
                'Newly detected obstacle blocks the current path — '
                'replanning (D* Lite) from current position.'
            )
            self.replan_from_here()

    # ------------------------------------------------------------------
    # Planning
    # ------------------------------------------------------------------

    def start_new_plan(self, target_x, target_y, target_z):
        """A genuinely new target — D* Lite state cannot be reused."""
        start_grid = world_to_grid(self.current_x, self.current_y)
        goal_grid = world_to_grid(target_x, target_y)

        if not in_bounds(*goal_grid) or is_occupied(*goal_grid, self._dynamic_obstacles):
            self.get_logger().warn(
                'Target is outside the arena or inside an obstacle — rejected.')
            return
        if is_occupied(*start_grid, self._dynamic_obstacles):
            start_grid = self._nearest_free_cell(start_grid)

        # Re-create DStarLite so it holds a reference to the current
        # _dynamic_obstacles list (FIX 4).
        self.dstar = DStarLite(self._dynamic_obstacles)
        self.dstar.initialize(start_grid, goal_grid)
        # FIX 3: only snapshot occupancy when we actually plan.
        self.occupancy_cache = self._snapshot_occupancy()
        self.dstar.compute_shortest_path()
        # Reset cooldown to a long time ago so the FIRST obstacle detection
        # after a new target always triggers a replan immediately.
        # The 2s cooldown should only throttle REPEATED replans, not the first one.
        from rclpy.duration import Duration as _Dur
        self.last_replan_attempt = self.get_clock().now() - _Dur(seconds=REPLAN_COOLDOWN_SEC + 1.0)
        self._publish_from_dstar(target_x, target_y, target_z)

    def replan_from_here(self):
        """Same target, map changed — incremental D* Lite replan."""
        if self.current_target is None:
            return

        # FIX 1: stamp the attempt time NOW, before compute_shortest_path,
        # so failed replans ("No path found") also update the cooldown and
        # don't immediately fire again on the next camera frame.
        self.last_replan_attempt = self.get_clock().now()

        tx, ty, tz = self.current_target
        start_grid = world_to_grid(self.current_x, self.current_y)
        if is_occupied(*start_grid, self._dynamic_obstacles):
            start_grid = self._nearest_free_cell(start_grid)

        self.dstar.update_start(start_grid)

        # FIX 3: snapshot only on actual replan.
        new_occupancy = self._snapshot_occupancy()
        changed = self.occupancy_cache.symmetric_difference(new_occupancy)
        self.occupancy_cache = new_occupancy
        if changed:
            self.dstar.notify_changed(changed)

        self.dstar.compute_shortest_path()
        self._publish_from_dstar(tx, ty, tz)

    def _snapshot_occupancy(self):
        """Capture which grid cells are currently occupied.
        Called only when a replan actually happens (FIX 3)."""
        return {
            (gx, gy)
            for gx in range(GRID_DIM)
            for gy in range(GRID_DIM)
            if is_occupied(gx, gy, self._dynamic_obstacles)
        }

    def _publish_from_dstar(self, target_x, target_y, target_z):
        grid_path = self.dstar.extract_path()
        if grid_path is None:
            self.get_logger().warn('No path found to target.')
            return

        world_path = [grid_to_world(gx, gy) for gx, gy in grid_path]
        world_path = simplify_path(world_path)
        world_path[-1] = (target_x, target_y)  # exact target, no grid quantisation

        path_msg = Path()
        path_msg.header.frame_id = 'world'
        path_msg.header.stamp = self.get_clock().now().to_msg()
        for (x, y) in world_path:
            pose = PoseStamped()
            pose.header = path_msg.header
            pose.pose.position.x = x
            pose.pose.position.y = y
            pose.pose.position.z = target_z
            pose.pose.orientation.w = 1.0
            path_msg.poses.append(pose)

        self.path_pub.publish(path_msg)
        self.current_target = (target_x, target_y, target_z)
        self.current_path_world = world_path
        # NOTE: last_replan_attempt is set at the START of replan_from_here()
        # (FIX 1), so we only update it here for new-target plans where
        # start_new_plan() is the entry point.
        self.last_replan_attempt = self.get_clock().now()
        self.get_logger().info(
            f'Published path with {len(world_path)} waypoint(s) '
            f'({len(grid_path)} raw grid cells before simplification).'
        )

    # ------------------------------------------------------------------
    # Helpers
    # ------------------------------------------------------------------

    def _path_blocked(self, path_world, dynamic_obstacles):
        """Check whether any segment of path_world passes through an
        occupied cell, using the given dynamic_obstacles snapshot."""
        for p1, p2 in zip(path_world, path_world[1:]):
            if self._segment_blocked(p1, p2, dynamic_obstacles):
                return True
        return False

    @staticmethod
    def _segment_blocked(p1, p2, dynamic_obstacles, step=0.2):
        x1, y1 = p1
        x2, y2 = p2
        dist = math.hypot(x2 - x1, y2 - y1)
        steps = max(1, int(dist / step))
        for i in range(steps + 1):
            t = i / steps
            x = x1 + (x2 - x1) * t
            y = y1 + (y2 - y1) * t
            gx, gy = world_to_grid(x, y)
            if not in_bounds(gx, gy) or is_occupied(gx, gy, dynamic_obstacles):
                return True
        return False

    def _nearest_free_cell(self, cell, max_radius=5):
        for r in range(1, max_radius + 1):
            for dx in range(-r, r + 1):
                for dy in range(-r, r + 1):
                    candidate = (cell[0] + dx, cell[1] + dy)
                    if in_bounds(*candidate) and \
                       not is_occupied(*candidate, self._dynamic_obstacles):
                        return candidate
        return cell


def main():
    rclpy.init()
    node = PathPlanner()
    try:
        rclpy.spin(node)
    except KeyboardInterrupt:
        pass
    finally:
        node.destroy_node()
        rclpy.shutdown()


if __name__ == '__main__':
    main()