#!/usr/bin/env python3
"""
Obstacle detector for the quadcopter's front depth camera.

Subscribes:  /quadcopter/camera/points      (sensor_msgs/PointCloud2)
Publishes:   /quadcopter/detected_obstacles  (visualization_msgs/MarkerArray)
"""

from collections import deque

import numpy as np
import rclpy
from rclpy.node import Node
from rclpy.time import Time
from rclpy.duration import Duration

from sensor_msgs.msg import PointCloud2
from sensor_msgs_py import point_cloud2 as pc2
from visualization_msgs.msg import Marker, MarkerArray

import tf2_ros
from tf2_ros import TransformException

VOXEL_SIZE             = 0.5
MIN_POINTS_PER_VOXEL   = 4
MIN_VOXELS_PER_CLUSTER = 2
GROUND_CLEARANCE       = 0.15
CEILING_HEIGHT         = 4.5
ARENA_MIN              = -10.0
ARENA_MAX              =  10.0
MIN_OBSTACLE_FOOTPRINT = 0.15
CONFIRM_FRAMES         = 3
DECAY_FRAMES           = 4

NEIGHBOR_OFFSETS = [
    (dx, dy, dz)
    for dx in (-1, 0, 1) for dy in (-1, 0, 1) for dz in (-1, 0, 1)
    if not (dx == 0 and dy == 0 and dz == 0)
]


class ObstacleDetector(Node):
    def __init__(self):
        super().__init__('obstacle_detector')

        # Larger buffer so we can always find a recent transform
        self.tf_buffer   = tf2_ros.Buffer(cache_time=Duration(seconds=30.0))
        self.tf_listener = tf2_ros.TransformListener(self.tf_buffer, self)

        self.marker_pub = self.create_publisher(
            MarkerArray, '/quadcopter/detected_obstacles', 10)
        self.cloud_sub  = self.create_subscription(
            PointCloud2, '/quadcopter/camera/points', self.cloud_callback, 5)

        self._confirm: dict[tuple, int] = {}

        self.get_logger().info(
            'Obstacle detector ready — /quadcopter/detected_obstacles')

    # ------------------------------------------------------------------
    # Subscriber
    # ------------------------------------------------------------------

    def cloud_callback(self, msg: PointCloud2):
        # Always use Time(0) = "latest available" transform.
        # odom_tf_broadcaster now publishes zero-stamped transforms,
        # so Time(0) lookups always succeed — no more TF_OLD_DATA.
        try:
            transform = self.tf_buffer.lookup_transform(
                'world',
                msg.header.frame_id,
                Time(),                        # latest / zero-stamped
                timeout=Duration(seconds=0.05))
        except TransformException as e:
            self.get_logger().warn(
                f'TF lookup failed: {e}',
                throttle_duration_sec=3.0)
            return

        # Read points; skip_nans handles NaN, isfinite handles Inf
        raw = np.array([
            [p[0], p[1], p[2]]
            for p in pc2.read_points(
                msg, field_names=('x', 'y', 'z'), skip_nans=True)
        ], dtype=np.float64)

        if raw.shape[0] == 0:
            self._publish_confirmed({})
            return

        finite_mask = np.all(np.isfinite(raw), axis=1)
        pts = raw[finite_mask]

        if pts.shape[0] == 0:
            self._publish_confirmed({})
            return

        t = transform.transform.translation
        q = transform.transform.rotation

        # Guard against bad quaternion at startup
        norm = (q.x**2 + q.y**2 + q.z**2 + q.w**2) ** 0.5
        if not (0.99 < norm < 1.01):
            self.get_logger().warn(
                f'Bad quaternion norm {norm:.4f} — skipping',
                throttle_duration_sec=2.0)
            return

        pts_world = self._apply_transform(pts, t, q)

        mask  = (pts_world[:, 2] > GROUND_CLEARANCE) & \
                (pts_world[:, 2] < CEILING_HEIGHT)
        mask &= (pts_world[:, 0] > ARENA_MIN) & (pts_world[:, 0] < ARENA_MAX)
        mask &= (pts_world[:, 1] > ARENA_MIN) & (pts_world[:, 1] < ARENA_MAX)
        pts_world = pts_world[mask]

        if pts_world.shape[0] == 0:
            self._publish_confirmed({})
            return

        clusters = self.cluster_points(pts_world)
        self._publish_confirmed({self._key(c): c for c in clusters})

    # ------------------------------------------------------------------
    # Helpers
    # ------------------------------------------------------------------

    @staticmethod
    def _apply_transform(pts: np.ndarray, t, q) -> np.ndarray:
        x, y, z, w = q.x, q.y, q.z, q.w
        R = np.array([
            [1 - 2*(y*y + z*z),     2*(x*y - z*w),     2*(x*z + y*w)],
            [    2*(x*y + z*w), 1 - 2*(x*x + z*z),     2*(y*z - x*w)],
            [    2*(x*z - y*w),     2*(y*z + x*w), 1 - 2*(x*x + y*y)],
        ], dtype=np.float64)
        out = (R @ pts.T).T
        out[:, 0] += t.x
        out[:, 1] += t.y
        out[:, 2] += t.z
        return out

    @staticmethod
    def _key(bb) -> tuple:
        return (
            round((bb[0] + bb[1]) / 2 / VOXEL_SIZE),
            round((bb[2] + bb[3]) / 2 / VOXEL_SIZE),
            round((bb[4] + bb[5]) / 2 / VOXEL_SIZE),
        )

    # ------------------------------------------------------------------
    # Clustering
    # ------------------------------------------------------------------

    def cluster_points(self, points: np.ndarray) -> list:
        voxel_idx = np.floor(points / VOXEL_SIZE).astype(np.int32)
        unique_voxels, inverse, counts = np.unique(
            voxel_idx, axis=0, return_inverse=True, return_counts=True)

        occupied_mask = counts >= MIN_POINTS_PER_VOXEL
        occupied_set  = {tuple(v) for v in unique_voxels[occupied_mask]}
        if not occupied_set:
            return []

        voxel_to_points = {
            tuple(unique_voxels[vid]): np.where(inverse == vid)[0]
            for vid in np.nonzero(occupied_mask)[0]
        }

        visited  = set()
        clusters = []

        for voxel in occupied_set:
            if voxel in visited:
                continue
            component = []
            queue = deque([voxel])
            visited.add(voxel)
            while queue:
                v = queue.popleft()
                component.append(v)
                for off in NEIGHBOR_OFFSETS:
                    nb = (v[0]+off[0], v[1]+off[1], v[2]+off[2])
                    if nb in occupied_set and nb not in visited:
                        visited.add(nb)
                        queue.append(nb)

            if len(component) < MIN_VOXELS_PER_CLUSTER:
                continue

            idxs        = np.concatenate([voxel_to_points[v] for v in component])
            cluster_pts = points[idxs]
            xmin, ymin, zmin = cluster_pts.min(axis=0)
            xmax, ymax, zmax = cluster_pts.max(axis=0)

            if (xmax - xmin) < MIN_OBSTACLE_FOOTPRINT or \
               (ymax - ymin) < MIN_OBSTACLE_FOOTPRINT:
                continue

            clusters.append((float(xmin), float(xmax),
                             float(ymin), float(ymax),
                             float(zmin), float(zmax)))

        return clusters

    # ------------------------------------------------------------------
    # Confirmation filter with decay
    # ------------------------------------------------------------------

    def _publish_confirmed(self, current_keys: dict):
        new_confirm = {}
        all_keys = set(self._confirm.keys()) | set(current_keys.keys())
        for k in all_keys:
            if k in current_keys:
                prev = self._confirm.get(k, 0)
                new_confirm[k] = max(prev, 0) + 1
            else:
                prev = self._confirm.get(k, 0)
                nv = prev - 1
                if nv >= -DECAY_FRAMES:
                    new_confirm[k] = nv
        self._confirm = new_confirm

        confirmed = [
            current_keys[k]
            for k, count in self._confirm.items()
            if count >= CONFIRM_FRAMES and k in current_keys
        ]
        self._publish_markers(confirmed)

    # ------------------------------------------------------------------
    # Publisher
    # ------------------------------------------------------------------

    def _publish_markers(self, clusters: list):
        markers = MarkerArray()

        clear = Marker()
        clear.header.frame_id = 'world'
        clear.action = Marker.DELETEALL
        markers.markers.append(clear)

        for i, (xmin, xmax, ymin, ymax, zmin, zmax) in enumerate(clusters):
            m = Marker()
            m.header.frame_id    = 'world'
            m.header.stamp       = self.get_clock().now().to_msg()
            m.ns                 = 'dynamic_obstacles'
            m.id                 = i
            m.type               = Marker.CUBE
            m.action             = Marker.ADD
            m.pose.position.x    = (xmin + xmax) / 2.0
            m.pose.position.y    = (ymin + ymax) / 2.0
            m.pose.position.z    = (zmin + zmax) / 2.0
            m.pose.orientation.w = 1.0
            m.scale.x            = max(xmax - xmin, 0.05)
            m.scale.y            = max(ymax - ymin, 0.05)
            m.scale.z            = max(zmax - zmin, 0.05)
            m.color.r            = 1.0
            m.color.g            = 0.2
            m.color.b            = 0.2
            m.color.a            = 0.5
            markers.markers.append(m)

        self.marker_pub.publish(markers)
        if clusters:
            self.get_logger().info(
                f'Detected {len(clusters)} confirmed obstacle(s).',
                throttle_duration_sec=1.0)


def main():
    rclpy.init()
    node = ObstacleDetector()
    try:
        rclpy.spin(node)
    except KeyboardInterrupt:
        pass
    finally:
        node.destroy_node()
        rclpy.shutdown()


if __name__ == '__main__':
    main()