#!/usr/bin/env python3
"""
Dynamic TF broadcaster: world -> quadcopter/base_link

The key change vs previous versions: we broadcast with Time(0) (zero stamp)
instead of msg.header.stamp. A zero-stamped transform in tf2 means
"valid at all times" — it's always returned regardless of the lookup
timestamp. This is the correct approach for a transform that updates
continuously from odometry, because:

1. The point cloud lookup uses msg.header.stamp (sim time). The static
   camera transform is published by static_transform_publisher at wall
   clock t=0, which never matches sim time → TF_OLD_DATA on every frame.

2. Using Time(0) here means obstacle_detector can always find
   world->base_link regardless of sim time, and the static publisher's
   zero-stamp camera transform is also always valid. Both ends of the
   chain become timestamp-independent → no more TF_OLD_DATA.

Subscribes: /quadcopter/gps_odometry (nav_msgs/Odometry)
Broadcasts: TF world -> quadcopter/base_link
"""

import rclpy
from rclpy.node import Node
from nav_msgs.msg import Odometry
from tf2_ros import TransformBroadcaster
from geometry_msgs.msg import TransformStamped
from builtin_interfaces.msg import Time as TimeMsg

RESET_THRESHOLD_SEC = 1.0


class OdomTfBroadcaster(Node):
    def __init__(self):
        super().__init__('odom_tf_broadcaster')

        self.broadcaster = TransformBroadcaster(self)
        self.sub = self.create_subscription(
            Odometry, '/quadcopter/gps_odometry', self.odom_callback, 10)

        self._last_stamp_sec = None
        self.get_logger().info(
            'Broadcasting world -> quadcopter/base_link TF (zero-stamped)')

    def odom_callback(self, msg: Odometry):
        stamp_sec = msg.header.stamp.sec + msg.header.stamp.nanosec * 1e-9

        # Detect sim reset (time jumps backwards)
        if self._last_stamp_sec is not None:
            if stamp_sec - self._last_stamp_sec < -RESET_THRESHOLD_SEC:
                self.get_logger().warn(
                    f'Sim reset detected — time jumped from '
                    f'{self._last_stamp_sec:.2f}s to {stamp_sec:.2f}s. '
                    f'Recreating TF broadcaster.')
                self.broadcaster = TransformBroadcaster(self)

        self._last_stamp_sec = stamp_sec

        t = TransformStamped()

        # Zero stamp = "valid at all times" in tf2.
        # This is what static_transform_publisher does internally.
        # It means lookup_transform succeeds regardless of what timestamp
        # the caller requests, eliminating TF_OLD_DATA entirely.
        t.header.stamp = TimeMsg(sec=0, nanosec=0)
        t.header.frame_id = 'world'
        t.child_frame_id = 'quadcopter/base_link'

        t.transform.translation.x = msg.pose.pose.position.x
        t.transform.translation.y = msg.pose.pose.position.y
        t.transform.translation.z = msg.pose.pose.position.z
        t.transform.rotation = msg.pose.pose.orientation

        self.broadcaster.sendTransform(t)


def main():
    rclpy.init()
    node = OdomTfBroadcaster()
    try:
        rclpy.spin(node)
    except KeyboardInterrupt:
        pass
    finally:
        node.destroy_node()
        rclpy.shutdown()


if __name__ == '__main__':
    main()