#!/usr/bin/env python3
"""
Autonomous waypoint follower for the quadcopter.

Subscribes:  /quadcopter/gps_odometry  (nav_msgs/Odometry)
             /quadcopter/planned_path  (nav_msgs/Path)
Publishes:   /quadcopter/cmd_vel       (geometry_msgs/Twist)
"""

import math

import rclpy
from rclpy.node import Node
from geometry_msgs.msg import Twist
from nav_msgs.msg import Odometry, Path

MAX_LINEAR_SPEED   = 1.5   # m/s
KP                 = 0.6
# Raised from 0.1 — GPS odometry has ~0.3-0.5m noise in Gazebo sim,
# so 0.1m tolerance meant the drone would circle a waypoint forever.
POSITION_TOLERANCE = 0.5   # metres


class GoToPosition(Node):
    def __init__(self):
        super().__init__('go_to_position')

        self.target_x   = None
        self.target_y   = None
        self.target_z   = None

        self.current_x  = 0.0
        self.current_y  = 0.0
        self.current_z  = 0.0
        self.have_odom  = False
        self.have_target = False
        self.arrived    = False
        self.waypoints  = []
        self.waypoint_index = 0

        self.cmd_pub  = self.create_publisher(Twist, '/quadcopter/cmd_vel', 10)
        self.odom_sub = self.create_subscription(
            Odometry, '/quadcopter/gps_odometry', self.odom_callback, 10)
        self.path_sub = self.create_subscription(
            Path, '/quadcopter/planned_path', self.path_callback, 10)

        self.timer = self.create_timer(1.0 / 20.0, self.control_loop)

        self.get_logger().info(
            'Waiting for a path on /quadcopter/planned_path '
            '(set a target in the Gazebo GUI "Set Target Position" panel)'
        )

    def odom_callback(self, msg: Odometry):
        self.current_x = msg.pose.pose.position.x
        self.current_y = msg.pose.pose.position.y
        self.current_z = msg.pose.pose.position.z
        self.have_odom = True

    def path_callback(self, msg: Path):
        if not msg.poses:
            self.get_logger().warn('Received an empty path — ignoring.')
            return

        self.waypoints = [
            (p.pose.position.x, p.pose.position.y, p.pose.position.z)
            for p in msg.poses
        ]
        self.waypoint_index = 0
        self.target_x, self.target_y, self.target_z = self.waypoints[0]
        self.have_target = True
        self.arrived     = False
        self.get_logger().info(
            f'New path received: {len(self.waypoints)} waypoint(s). '
            f'Heading to waypoint 1: '
            f'({self.target_x:.2f}, {self.target_y:.2f}, {self.target_z:.2f})'
        )

    def control_loop(self):
        if not self.have_odom or not self.have_target or self.arrived:
            return

        error_x = self.target_x - self.current_x
        error_y = self.target_y - self.current_y
        error_z = self.target_z - self.current_z

        distance = math.sqrt(error_x**2 + error_y**2 + error_z**2)

        if distance < POSITION_TOLERANCE:
            self.waypoint_index += 1
            if self.waypoint_index < len(self.waypoints):
                self.target_x, self.target_y, self.target_z = \
                    self.waypoints[self.waypoint_index]
                self.get_logger().info(
                    f'Reached waypoint {self.waypoint_index}/{len(self.waypoints)}. '
                    f'Heading to next: '
                    f'({self.target_x:.2f}, {self.target_y:.2f}, {self.target_z:.2f})'
                )
                return
            self.stop()
            self.arrived = True
            self.get_logger().info(
                f'Arrived at final target (within {POSITION_TOLERANCE}m). Holding position.'
            )
            return

        vx = KP * error_x
        vy = KP * error_y
        vz = KP * error_z

        speed = math.sqrt(vx**2 + vy**2 + vz**2)
        if speed > MAX_LINEAR_SPEED:
            scale = MAX_LINEAR_SPEED / speed
            vx *= scale
            vy *= scale
            vz *= scale

        msg = Twist()
        msg.linear.x = vx
        msg.linear.y = vy
        msg.linear.z = vz
        self.cmd_pub.publish(msg)

    def stop(self):
        self.cmd_pub.publish(Twist())


def main():
    rclpy.init()
    node = GoToPosition()
    try:
        rclpy.spin(node)
    except KeyboardInterrupt:
        pass
    finally:
        node.stop()
        node.destroy_node()
        rclpy.shutdown()


if __name__ == '__main__':
    main()