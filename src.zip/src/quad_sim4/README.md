# Switching quad_sim4 to the PX4 x500 model

## What changed

- `worlds/quad_world.sdf` — the `<model name="quadcopter">` block now uses the
  official PX4/PX4-gazebo-models **x500_base** body: real frame mesh, 4 motor
  bases, correct mass (2.0 kg body + 4×0.0161 kg rotors ≈ 2.06 kg total vs.
  the old 1.6 kg), correct inertias, and the real rotor spread (±0.174 m vs.
  the old ±0.2 m). Everything else — arena walls, ground plane, GUI panels,
  `spherical_coordinates`, lighting — is untouched.
- Your GPS sensor and front depth camera are carried over unchanged (same
  topics, same camera pose/offset), so `gps_odom_converter.py`,
  `odom_tf_broadcaster.py`, `go_to_position.py`, `quad_teleop.py`, and the
  ROS2 bridge topic list all need **zero code changes**.
- Rotor turning directions changed to match the real x500 layout: rotor_0
  (front-right) and rotor_1 (back-left) are now the CCW diagonal pair,
  rotor_2 (front-left) and rotor_3 (back-right) are the CW pair — the
  opposite pairing from your old model. `MulticopterVelocityControl`'s
  `rotorConfiguration/direction` values were updated to match
  (`+1 = CCW` → rotor_0/1, `-1 = CW` → rotor_2/3).
- `motorConstant`, `momentConstant`, `rotorDragCoefficient`,
  `rollingMomentCoefficient`, and `maxRotVelocity` were already the real x500
  values in your old file, so those didn't need to change.
- `models/x500_base/` — the mesh/texture assets the world file's `model://`
  URIs point to (`NXP-HGD-CF.dae` frame, `5010Base.dae`/`5010Bell.dae` motor
  parts, `1345_prop_ccw.stl`/`1345_prop_cw.stl` propellers, textures).
- `launch/quad_sim4_launch.py` — adds one `SetEnvironmentVariable` for
  `GZ_SIM_RESOURCE_PATH` so Gazebo can resolve those `model://x500_base/...`
  mesh URIs. Nothing else in the launch file changed.

## Where these files go in your workspace

```
~/program_ws/src/quad_sim4/
├── worlds/quad_world.sdf        <- replace
├── models/x500_base/            <- add (whole folder)
└── launch/quad_sim4_launch.py   <- replace
```

## One CMakeLists.txt change needed

Your `install(...)` rules currently install `worlds/` but not `models/`.
Add (or extend) an install line so the mesh files ship to the install space:

```cmake
install(DIRECTORY worlds models launch
  DESTINATION share/${PROJECT_NAME}
)
```

If you already have a similar `install(DIRECTORY ...)` line for `worlds`,
just add `models` to the same list rather than duplicating the rule.

## Build and run

```bash
cd ~/program_ws
colcon build --packages-select quad_sim4
source install/setup.bash
ros2 launch quad_sim4 quad_sim4_launch.py
```

## Things to sanity-check on first run

- **Visuals load**: if the drone spawns with no visible mesh (just moves
  invisibly, or you see console warnings about unresolved `model://`
  URIs), the `GZ_SIM_RESOURCE_PATH` isn't reaching `gz sim` — check that
  `models/` was actually installed (previous section) and that
  `models_path` in the launch file resolves to a real directory.
- **Flight feel**: the x500 is ~29% heavier than your old model (2.06 kg vs
  1.6 kg). `MulticopterVelocityControl`'s gains were left as-is since the
  controller computes required thrust from actual mass rather than an
  open-loop hover speed, so it should still fly — but it may feel a little
  softer/slower to respond than before. If it feels sluggish or oscillates,
  the usual knobs are `velocityGain` (position tracking) and
  `attitudeGain`/`angularRateGain` (tilt response) in the
  `MulticopterVelocityControl` plugin.
- **Spawn height**: pose changed from `0 0 0.2` to `0 0 0.24` to match the
  x500's actual leg length — if the drone starts slightly embedded in or
  floating above the ground plane, nudge this pose.
- **Ground plane color**: the arena walls and ground plane are unchanged, so
  the x500's grey/carbon-fiber look will look different against them, but
  nothing about that is broken — purely cosmetic.
