import os
from launch import LaunchDescription
from launch.actions import ExecuteProcess
from launch_ros.actions import Node
from ament_index_python.packages import get_package_share_directory


def generate_launch_description():
    pkg_share = get_package_share_directory('quad_sim1')
    world_path = os.path.join(pkg_share, 'worlds', 'quad_world.sdf')

    install_prefix = os.path.dirname(os.path.dirname(pkg_share))
    teleop_script = os.path.join(install_prefix, 'lib', 'quad_sim1', 'quad_teleop.py')

    gz_sim = ExecuteProcess(
        cmd=['gz', 'sim', world_path],
        output='screen'
    )

    # Bridge /quadcopter/cmd_vel (ROS2 -> Gazebo) and /quadcopter/enable (ROS2 -> Gazebo)
    bridge = Node(
        package='ros_gz_bridge',
        executable='parameter_bridge',
        arguments=[
            '/quadcopter/cmd_vel@geometry_msgs/msg/Twist@gz.msgs.Twist',
            '/quadcopter/enable@std_msgs/msg/Bool@gz.msgs.Boolean',
        ],
        output='screen'
    )

    # 3D keyboard teleop, run in its own terminal so it can capture keystrokes
    teleop = ExecuteProcess(
        cmd=['gnome-terminal', '--', 'bash', '-c', 'python3 ' + teleop_script + '; echo; echo "[teleop exited, press Enter to close]"; read'],
        output='screen'
    )

    return LaunchDescription([
        gz_sim,
        bridge,
        teleop,
    ])