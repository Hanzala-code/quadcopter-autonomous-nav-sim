import rclpy
from rclpy.node import Node
from std_msgs.msg import Float32, String

TOPIC1 = 'float_topic'
TOPIC2 = 'string_topic'

class SubscriberNode(Node):
    def __init__(self):
        super().__init__('subscriber_node')
        
        # Create subscribers
        self.sub_float = self.create_subscription(
            Float32, 
            TOPIC1, 
            self.callback_fun1, 
            10
        )
        self.sub_string = self.create_subscription(
            String, 
            TOPIC2, 
            self.callback_fun2, 
            10
        )
        
        # Prevent unused variable warnings
        self.sub_float
        self.sub_string

    def callback_fun1(self, msg):
        self.get_logger().info(f'Received Float: {msg.data:.2f}')

    def callback_fun2(self, msg):
        self.get_logger().info(f'Received String: "{msg.data}"')

def main(args=None):
    rclpy.init(args=args)
    subscriber_node = SubscriberNode()
    
    try:
        rclpy.spin(subscriber_node)
    except KeyboardInterrupt:
        pass
    finally:
        subscriber_node.destroy_node()
        rclpy.shutdown()

if __name__ == '__main__':
    main()