import rclpy
from rclpy.node import Node
from std_msgs.msg import Float32, String

TOPIC1 = 'float_topic'
TOPIC2 = 'string_topic'

class PublisherNode(Node):
    def __init__(self):
        super().__init__('publisher_node')
        
        # Create publishers for float and string topics
        self.pub_float = self.create_publisher(Float32, TOPIC1, 10)
        self.pub_string = self.create_publisher(String, TOPIC2, 10)
        
        # Set timer period (1 second)
        timer_period = 1.0
        self.timer = self.create_timer(timer_period, self.callback_fun)
        
        # Variables to transmit
        self.count = 0
        self.value = 0.0

    def callback_fun(self):
        # Create ROS message objects
        msg1 = Float32()
        msg2 = String()
        
        # Increment float value
        self.value += 0.01
        msg1.data = self.value
        
        # Populate string message
        msg2.data = f'Message number: {self.count}'
        
        # Publish messages
        self.pub_string.publish(msg2)
        self.pub_float.publish(msg1)
        
        # Print status to terminal
        self.get_logger().info(f'Publishing: "{msg2.data}" | Float: {msg1.data:.2f}')
        
        self.count += 1

def main(args=None):
    rclpy.init(args=args)
    publisher_node = PublisherNode()
    
    try:
        rclpy.spin(publisher_node)
    except KeyboardInterrupt:
        pass
    finally:
        publisher_node.destroy_node()
        rclpy.shutdown()

if __name__ == '__main__':
    main()